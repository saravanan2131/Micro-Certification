<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/response.php';
$pdo = db(); $method = $_SERVER['REQUEST_METHOD'];
switch($method){
  case 'GET':
    $stmt = $pdo->query("SELECT id,name,address,capacity,price_per_day FROM venues ORDER BY name");
    json_response(['ok'=>true,'data'=>$stmt->fetchAll()]);
    break;
  case 'POST':
    $data = read_json_body(); foreach(['name','address','capacity','price_per_day'] as $f) if(!isset($data[$f])) json_response(['ok'=>false,'error'=>"$f required"],422);
    $stmt = $pdo->prepare("INSERT INTO venues(name,address,capacity,price_per_day) VALUES (?,?,?,?)"); $stmt->execute([$data['name'],$data['address'],intval($data['capacity']),$data['price_per_day']]); json_response(['ok'=>true,'id'=>$pdo->lastInsertId()]);
    break;
  case 'PUT':
    parse_str($_SERVER['QUERY_STRING'] ?? '', $q); $id = intval($q['id'] ?? 0); if($id<=0) json_response(['ok'=>false,'error'=>'id required'],422);
    $data = read_json_body(); $fields=[];$vals=[]; foreach(['name','address','capacity','price_per_day'] as $f) if(isset($data[$f])){ $fields[]="$f=?"; $vals[]=$data[$f]; }
    if(!$fields) json_response(['ok'=>false,'error'=>'no fields'],422); $vals[]=$id; $stmt = $pdo->prepare("UPDATE venues SET ".implode(',', $fields)." WHERE id=?"); $stmt->execute($vals); json_response(['ok'=>true]);
    break;
  case 'DELETE':
    parse_str($_SERVER['QUERY_STRING'] ?? '', $q); $id=intval($q['id'] ?? 0); if($id<=0) json_response(['ok'=>false,'error'=>'id required'],422);
    $stmt = $pdo->prepare("DELETE FROM venues WHERE id=?"); $stmt->execute([$id]); json_response(['ok'=>true]);
    break;
  default: json_response(['ok'=>false,'error'=>'method not allowed'],405);
}
?>

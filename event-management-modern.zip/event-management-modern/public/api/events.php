<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/response.php';
$pdo = db(); $method = $_SERVER['REQUEST_METHOD'];
switch($method){
  case 'GET':
    $stmt = $pdo->query("SELECT e.id,e.name,e.event_date,e.capacity,e.status,v.name as venue FROM events e LEFT JOIN venues v ON v.id=e.venue_id ORDER BY e.event_date ASC");
    $rows = $stmt->fetchAll();
    json_response(['ok'=>true,'data'=>$rows]);
    break;
  case 'POST':
    $data = read_json_body();
    if(!isset($data['name'],$data['event_date'])) json_response(['ok'=>false,'error'=>'name and event_date required'],422);
    $stmt = $pdo->prepare("INSERT INTO events(name,description,event_date,start_time,end_time,venue_id,capacity,price,status) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$data['name'],$data['description'] ?? null,$data['event_date'],$data['start_time'] ?? null,$data['end_time'] ?? null,$data['venue_id'] ?? null,intval($data['capacity'] ?? 0),$data['price'] ?? 0,$data['status'] ?? 'planning']);
    json_response(['ok'=>true,'id'=>$pdo->lastInsertId()]);
    break;
  case 'PUT':
    parse_str($_SERVER['QUERY_STRING'] ?? '', $q); $id = intval($q['id'] ?? 0);
    if($id<=0) json_response(['ok'=>false,'error'=>'id required'],422);
    $data = read_json_body(); $fields=[];$vals=[];
    foreach(['name','description','event_date','start_time','end_time','venue_id','capacity','price','status'] as $f){ if(isset($data[$f])){ $fields[]="$f=?"; $vals[]=$data[$f]; } }
    if(!$fields) json_response(['ok'=>false,'error'=>'no fields'],422);
    $vals[]=$id; $sql = "UPDATE events SET ".implode(',', $fields)." WHERE id=?"; $stmt = $pdo->prepare($sql); $stmt->execute($vals); json_response(['ok'=>true]);
    break;
  case 'DELETE':
    parse_str($_SERVER['QUERY_STRING'] ?? '', $q); $id=intval($q['id'] ?? 0);
    if($id<=0) json_response(['ok'=>false,'error'=>'id required'],422);
    $stmt = $pdo->prepare("DELETE FROM events WHERE id=?"); $stmt->execute([$id]); json_response(['ok'=>true]);
    break;
  default: json_response(['ok'=>false,'error'=>'method not allowed'],405);
}
?>

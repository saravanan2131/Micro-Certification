<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/response.php';
$pdo = db();
// aggregates
$data = [
  'upcoming_events' => (int)$pdo->query("SELECT COUNT(*) FROM events WHERE event_date >= CURDATE()")->fetchColumn(),
  'total_attendees' => (int)$pdo->query("SELECT COUNT(*) FROM attendees")->fetchColumn(),
  'venues_booked' => (int)$pdo->query("SELECT COUNT(DISTINCT venue_id) FROM events WHERE venue_id IS NOT NULL")->fetchColumn(),
  'revenue' => (float)$pdo->query("SELECT COALESCE(SUM(price),0) FROM events")->fetchColumn(),
];
json_response(['ok'=>true,'data'=>$data]);
?>

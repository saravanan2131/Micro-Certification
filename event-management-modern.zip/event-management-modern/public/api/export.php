<?php
require_once __DIR__ . '/../../config/db.php';
$pdo = db();
$type = $_GET['type'] ?? 'events';
if($type==='events'){
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="events.csv"');
  $out = fopen('php://output','w');
  fputcsv($out, ['ID','Name','Date','Venue','Capacity','Status']);
  $stmt = $pdo->query("SELECT e.id,e.name,e.event_date,v.name as venue,e.capacity,e.status FROM events e LEFT JOIN venues v ON v.id=e.venue_id ORDER BY e.event_date ASC");
  while($r=$stmt->fetch(PDO::FETCH_ASSOC)) fputcsv($out, $r);
  fclose($out); exit;
}
?>

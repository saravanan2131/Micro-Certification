
// public/app.js - frontend wiring (fetch API)

async function api(path, options={}){
  const res = await fetch('api/' + path, Object.assign({
    headers:{'Content-Type':'application/json'},
  }, options));
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function showModule(name){
  document.querySelectorAll('main .modules, main section').forEach(s=>s.style.display='none');
  document.querySelectorAll('nav a').forEach(a=>a.classList.remove('active'));
  const link = document.querySelector('nav a[data-module="'+name+'"]');
  if(link) link.classList.add('active');
  const el = document.getElementById(name);
  if(el) el.style.display = 'block';
}

document.addEventListener('DOMContentLoaded', ()=>{
  // nav
  document.querySelectorAll('nav a').forEach(a=>{
    a.addEventListener('click', (e)=>{ e.preventDefault(); showModule(a.dataset.module); if(a.dataset.module==='dashboard') refreshDashboard(); });
  });
  showModule('dashboard');
  // buttons
  document.getElementById('newEventBtn').addEventListener('click', ()=> showModule('events'));
  document.getElementById('addEventBtn').addEventListener('click', addEvent);
  document.getElementById('addVenueBtn').addEventListener('click', addVenue);
  document.getElementById('addAttendeeBtn').addEventListener('click', addAttendee);
  document.getElementById('refreshDashboard').addEventListener('click', refreshDashboard);
  document.getElementById('exportCSV').addEventListener('click', exportCSV);
  // initial loads
  loadEvents(); loadVenues(); loadAttendees(); refreshDashboard();
});

// Load functions
async function loadEvents(){
  try{
    const res = await api('events.php');
    const tbody = document.getElementById('eventsTable');
    if(!res.ok) return;
    tbody.innerHTML = '';
    res.data.forEach(r=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${r.name}</td><td>${r.event_date}</td><td>${r.venue||'-'}</td><td>${r.capacity}</td><td>${r.status}</td>
        <td><button class="btn secondary" onclick="editEvent(${r.id})">Edit</button> <button class="btn" onclick="deleteEvent(${r.id})">Delete</button></td>`;
      tbody.appendChild(tr);
    });
  }catch(e){ console.error(e); }
}

async function loadVenues(){
  try{
    const res = await api('venues.php');
    const grid = document.getElementById('venuesGrid');
    if(!res.ok) return;
    grid.innerHTML = '';
    res.data.forEach(v=>{
      const div = document.createElement('div');
      div.className = 'venue-card';
      div.innerHTML = `<img src="https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?w=800&q=60" alt=""><div>
        <h3 style="margin:0">${v.name}</h3><p style="margin:6px 0;color:var(--muted)">${v.address}</p>
        <div style="display:flex;gap:8px;margin-top:8px"><button class="btn" onclick="bookVenue(${v.id})">Book</button>
        <button class="btn secondary" onclick="editVenue(${v.id})">Edit</button></div></div>`;
      grid.appendChild(div);
    });
  }catch(e){ console.error(e); }
}

async function loadAttendees(){
  try{
    const res = await api('attendees.php');
    const tbody = document.getElementById('attendeesTable');
    if(!res.ok) return;
    tbody.innerHTML = '';
    res.data.forEach(a=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${a.name}</td><td>${a.email}</td><td>${a.phone}</td><td>${a.event}</td><td>${a.ticket_type}</td>
        <td><button class="btn" onclick="deleteAttendee(${a.id})">Remove</button></td>`;
      tbody.appendChild(tr);
    });
  }catch(e){ console.error(e); }
}

// Actions
async function addEvent(){
  const name = prompt('Event name');
  const date = prompt('Event date (YYYY-MM-DD)');
  const capacity = prompt('Capacity', '100');
  if(!name||!date) return alert('Name and date required');
  await api('events.php', {method:'POST', body: JSON.stringify({name, event_date: date, capacity: Number(capacity)})});
  loadEvents(); refreshDashboard(); showModule('events');
}

async function editEvent(id){
  const name = prompt('New name (leave blank to keep)');
  const date = prompt('New date YYYY-MM-DD (leave blank to keep)');
  const status = prompt('Status (planning,active,completed,cancelled)');
  const body = {};
  if(name) body.name = name; if(date) body.event_date = date; if(status) body.status = status;
  await api('events.php?id='+id, {method:'PUT', body: JSON.stringify(body)});
  loadEvents();
}

async function deleteEvent(id){
  if(!confirm('Delete this event?')) return;
  await fetch('api/events.php?id='+id, {method:'DELETE'});
  loadEvents(); refreshDashboard();
}

async function addVenue(){
  const name = prompt('Venue name'); const address = prompt('Address'); const capacity = prompt('Capacity'); const price = prompt('Price per day');
  if(!name||!address) return alert('Name and address required');
  await api('venues.php', {method:'POST', body: JSON.stringify({name,address,capacity:Number(capacity||0),price_per_day:price})});
  loadVenues();
}

async function editVenue(id){
  const name = prompt('New name'); const address = prompt('New address'); const capacity = prompt('Capacity'); const price = prompt('Price');
  const body = {}; if(name) body.name=name; if(address) body.address=address; if(capacity) body.capacity=Number(capacity); if(price) body.price_per_day=price;
  await api('venues.php?id='+id, {method:'PUT', body: JSON.stringify(body)}); loadVenues();
}

async function bookVenue(id){
  const name = prompt('Event name'); const date = prompt('Event date (YYYY-MM-DD)'); const capacity = prompt('Capacity', '100');
  if(!name||!date) return;
  await api('events.php', {method:'POST', body: JSON.stringify({name, event_date: date, venue_id: id, capacity: Number(capacity), status: 'active'})});
  loadEvents(); refreshDashboard(); alert('Booked & event created');
}

async function addAttendee(){
  const name = prompt('Attendee name'); const email = prompt('Email'); const phone = prompt('Phone'); const eventId = prompt('Event ID'); const ticket = prompt('Ticket Type','Standard'); const price = prompt('Price paid', '0');
  if(!name||!email||!eventId) return alert('Name, email, event required');
  await api('attendees.php', {method:'POST', body: JSON.stringify({name,email,phone,event_id: Number(eventId), ticket_type: ticket, price_paid: price})});
  loadAttendees(); refreshDashboard();
}

async function deleteAttendee(id){
  if(!confirm('Remove attendee?')) return; await fetch('api/attendees.php?id='+id, {method:'DELETE'}); loadAttendees(); refreshDashboard();
}

async function refreshDashboard(){
  try{
    const res = await api('reports.php');
    if(!res.ok) return;
    document.getElementById('statEvents').textContent = res.data.upcoming_events;
    document.getElementById('statAttendees').textContent = res.data.total_attendees;
    document.getElementById('statVenues').textContent = res.data.venues_booked;
  }catch(e){console.error(e);}
}

function exportCSV(){
  window.location = 'api/export.php?type=events';
}

// delete helpers are simple here but ok for demo

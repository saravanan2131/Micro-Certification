
Modern Event Management - PHP + MySQL
------------------------------------
1. Create database 'event_management' (or edit config/db.php)
2. Import migrations/schema.sql
3. Copy the 'event-management-modern' folder to your web server root (e.g., htdocs)
4. Start Apache + MySQL and visit /public/
Notes:
- Endpoints accept/return JSON. Edit config/db.php for credentials.
- Frontend uses prompt() dialogs for quick entry to preserve a minimal UI flow.

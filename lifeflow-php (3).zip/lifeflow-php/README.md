# LifeFlow - Blood Management System (PHP + MySQL)

## Quick start
1. Create the database and tables:
   - Import `migrations/schema.sql` into your MySQL server.
   - This creates database tables and seeds sample data.
2. Configure DB credentials in `config/config.php`.
3. Serve the `public/` folder from your PHP server (XAMPP/Apache/Nginx).
   - Example path on XAMPP: `C:\xampp\htdocs\lifeflow-php\public`
4. Visit `http://localhost/lifeflow-php/public/index.php`.

## Modules
- Dashboard (overview)
- Donors (CRUD)
- Inventory (add/list/delete, FEFO consumption on completion)
- Requests (create/list/view, complete/reject updates inventory)
- Reports (basic counts)

## Credentials
Default admin user: `admin` with password `admin123` (stored as SHA2 hash for demo). No login page is included in this scaffold.

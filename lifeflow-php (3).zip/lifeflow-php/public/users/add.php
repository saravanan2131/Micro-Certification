<?php
require_once __DIR__ . '/../../config/db.php';
session_start();
if (!isset($_SESSION['admin'])) { header("Location: ../login.php"); exit; }
$pdo = db();
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username']);
    $p = trim($_POST['password']);
    if ($u && $p) {
        $hash = password_hash($p, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO admin_users (username,password) VALUES (?,?)");
        $stmt->execute([$u,$hash]);
        header("Location: list.php");
        exit;
    } else {
        $msg = "All fields required.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Add Admin User</title></head>
<body>
<h2>Add Admin User</h2>
<?php if ($msg): ?><p style="color:red"><?= $msg ?></p><?php endif; ?>
<form method="post">
<label>Username</label><input type="text" name="username" required><br>
<label>Password</label><input type="password" name="password" required><br>
<button type="submit">Create</button>
</form>
</body>
</html>
<?php
require_once __DIR__ . '/../../config/db.php';
session_start();
if (!isset($_SESSION['admin'])) { header("Location: ../login.php"); exit; }
$pdo = db();

$id = $_GET['id'] ?? null;
if ($id) {
    // Prevent deleting yourself
    if ($id == $_SESSION['admin']['id']) {
        die("❌ You cannot delete your own account.");
    }
    $stmt = $pdo->prepare("DELETE FROM admin_users WHERE id = ?");
    $stmt->execute([$id]);
}
header("Location: list.php");
exit;

<?php
require_once __DIR__ . '/../../config/db.php';
session_start();
if (!isset($_SESSION['admin'])) { header("Location: ../login.php"); exit; }
$pdo = db();
$users = $pdo->query("SELECT id, username, created_at FROM admin_users")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head><title>Admin Users</title></head>
<body>
<h2>Admin Users</h2>
<a href="add.php">➕ Add New User</a>
<table border="1" cellpadding="5">
<tr><th>ID</th><th>Username</th><th>Created At</th><th>Actions</th></tr>
<?php foreach ($users as $u): ?>
<tr>
  <td><?= $u['id'] ?></td>
  <td><?= htmlspecialchars($u['username']) ?></td>
  <td><?= $u['created_at'] ?></td>
  <td>
    <a href="edit.php?id=<?= $u['id'] ?>">✏️ Edit</a> |
    <a href="delete.php?id=<?= $u['id'] ?>" onclick="return confirm('Delete this user?')">🗑️ Delete</a>
  </td>
</tr>
<?php endforeach; ?>
</table>
</body>
</html>

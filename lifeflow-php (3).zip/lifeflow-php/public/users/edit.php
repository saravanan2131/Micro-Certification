<?php
require_once __DIR__ . '/../../config/db.php';
session_start();
if (!isset($_SESSION['admin'])) { header("Location: ../login.php"); exit; }
$pdo = db();

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: list.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM admin_users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();
if (!$user) { header("Location: list.php"); exit; }

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    if ($username) {
        if ($password) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE admin_users SET username=?, password=? WHERE id=?");
            $stmt->execute([$username, $hash, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE admin_users SET username=? WHERE id=?");
            $stmt->execute([$username, $id]);
        }
        header("Location: list.php");
        exit;
    } else {
        $msg = "Username cannot be empty.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit Admin User</title></head>
<body>
<h2>Edit Admin User</h2>
<?php if ($msg): ?><p style="color:red"><?= $msg ?></p><?php endif; ?>
<form method="post">
<label>Username</label>
<input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required><br>
<label>New Password (leave blank to keep old)</label>
<input type="password" name="password"><br>
<button type="submit">Update</button>
</form>
</body>
</html>

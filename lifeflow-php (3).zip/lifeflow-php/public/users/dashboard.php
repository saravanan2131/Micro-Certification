<?php
require_once __DIR__ . '/../config/db.php';
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
$pdo = db();
$total_units = (int)$pdo->query("SELECT COALESCE(SUM(units),0) FROM blood_stock")->fetchColumn();
$total_donors = (int)$pdo->query("SELECT COUNT(*) FROM donors")->fetchColumn();
$total_hospitals = (int)$pdo->query("SELECT COUNT(*) FROM hospitals")->fetchColumn();
$pending_requests = (int)$pdo->query("SELECT COUNT(*) FROM requests WHERE status='pending'")->fetchColumn();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin Dashboard - LifeFlow</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
  <h1>Admin Dashboard</h1>
  <p>Welcome, <?= htmlspecialchars($_SESSION['admin']['username']) ?></p>
  <a href="logout.php">Logout</a>
  <div class="cards">
    <div class="card">Total Blood Units: <?= $total_units ?></div>
    <div class="card">Registered Donors: <?= $total_donors ?></div>
    <div class="card">Hospitals: <?= $total_hospitals ?></div>
    <div class="card">Pending Requests: <?= $pending_requests ?></div>
  </div>
</body>
</html>
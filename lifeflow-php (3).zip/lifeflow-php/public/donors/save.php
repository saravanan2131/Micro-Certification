<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();

$data = [
  'first_name' => $_POST['first_name'] ?? '',
  'last_name' => $_POST['last_name'] ?? '',
  'email' => $_POST['email'] ?? null,
  'phone' => $_POST['phone'] ?? null,
  'blood_type' => $_POST['blood_type'] ?? '',
  'last_donation_date' => $_POST['last_donation_date'] ?? null,
  'address' => $_POST['address'] ?? null,
  'city' => $_POST['city'] ?? null,
  'state' => $_POST['state'] ?? null,
  'zip' => $_POST['zip'] ?? null,
  'health_notes' => $_POST['health_notes'] ?? null,
];

if (!$data['first_name'] || !$data['last_name'] || !$data['blood_type']) {
  flash_set('err', 'Please fill required fields.');
  redirect(base_url('donors/new.php'));
}

$stmt = $pdo->prepare("
  INSERT INTO donors(first_name,last_name,email,phone,blood_type,last_donation_date,address,city,state,zip,health_notes)
  VALUES(:first_name,:last_name,:email,:phone,:blood_type,:last_donation_date,:address,:city,:state,:zip,:health_notes)
");
$stmt->execute($data);

flash_set('ok', 'Donor registered successfully.');
redirect(base_url('donors/list.php'));

<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$id = (int)($_GET['id'] ?? 0);
$donor = $pdo->prepare("SELECT * FROM donors WHERE id=?");
$donor->execute([$id]);
$donor = $donor->fetch();
include __DIR__ . '/../../partials/header.php';
if (!$donor): ?>
  <div class="card">Donor not found.</div>
<?php else: ?>
<section class="card">
  <h2 style="color:var(--primary);">Donor #<?= (int)$donor['id'] ?> — <?= h($donor['first_name'].' '.$donor['last_name']) ?></h2>
  <p><b>Blood:</b> <?= h($donor['blood_type']) ?> | <b>Phone:</b> <?= h($donor['phone']) ?> | <b>Email:</b> <?= h($donor['email']) ?></p>
  <p><b>Address:</b> <?= h($donor['address']) ?>, <?= h($donor['city']) ?>, <?= h($donor['state']) ?> <?= h($donor['zip']) ?></p>
  <p><b>Last Donation:</b> <?= h($donor['last_donation_date']) ?: '—' ?></p>
  <p><b>Health Notes:</b><br><?= nl2br(h($donor['health_notes'])) ?></p>
  <div style="display:flex; gap:.5rem;">
    <a class="btn" href="<?= base_url('donors/edit.php?id='.(int)$donor['id']) ?>">Edit</a>
    <a class="btn" onclick="return confirm('Delete this donor?')" href="<?= base_url('donors/remove.php?id='.(int)$donor['id']) ?>">Delete</a>
  </div>
</section>
<?php endif; ?>
<?php include __DIR__ . '/../../partials/footer.php'; ?>

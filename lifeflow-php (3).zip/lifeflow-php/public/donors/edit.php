<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM donors WHERE id=?");
$stmt->execute([$id]);
$d = $stmt->fetch();
include __DIR__ . '/../../partials/header.php';
if (!$d): ?>
  <div class="card">Donor not found.</div>
<?php else: ?>
<section class="card">
  <h2 style="color:var(--primary);">Edit Donor</h2>
  <form method="post" action="<?= base_url('donors/update.php') ?>">
    <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
    <div class="form-row">
      <div class="form-group"><label>First Name</label><input name="first_name" value="<?= h($d['first_name']) ?>" required></div>
      <div class="form-group"><label>Last Name</label><input name="last_name" value="<?= h($d['last_name']) ?>" required></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Email</label><input name="email" type="email" value="<?= h($d['email']) ?>"></div>
      <div class="form-group"><label>Phone</label><input name="phone" value="<?= h($d['phone']) ?>"></div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Blood Type</label>
        <select name="blood_type" required>
          <?php foreach(['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $t): ?>
            <option value="<?= $t ?>" <?= $d['blood_type']===$t?'selected':''; ?>><?= $t ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group"><label>Last Donation</label><input type="date" name="last_donation_date" value="<?= h($d['last_donation_date']) ?>"></div>
    </div>
    <div class="form-group"><label>Address</label><input name="address" value="<?= h($d['address']) ?>"></div>
    <div class="form-row">
      <div class="form-group"><label>City</label><input name="city" value="<?= h($d['city']) ?>"></div>
      <div class="form-group"><label>State</label><input name="state" value="<?= h($d['state']) ?>"></div>
      <div class="form-group"><label>ZIP</label><input name="zip" value="<?= h($d['zip']) ?>"></div>
    </div>
    <div class="form-group"><label>Health Notes</label><textarea name="health_notes" rows="3"><?= h($d['health_notes']) ?></textarea></div>
    <button class="btn btn-primary">Save Changes</button>
  </form>
</section>
<?php endif; ?>
<?php include __DIR__ . '/../../partials/footer.php'; ?>

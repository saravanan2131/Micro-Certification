<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$id = (int)($_GET['id'] ?? 0);
$pdo->prepare("DELETE FROM donors WHERE id=?")->execute([$id]);
flash_set('ok','Donor deleted.');
redirect(base_url('donors/list.php'));

<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
include __DIR__ . '/../../partials/header.php';
?>
<section class="card">
  <h2 style="color:var(--primary); margin-top:0;">Register New Donor</h2>
  <form method="post" action="<?= base_url('donors/save.php') ?>">
    <div class="form-row">
      <div class="form-group">
        <label>First Name</label>
        <input name="first_name" required>
      </div>
      <div class="form-group">
        <label>Last Name</label>
        <input name="last_name" required>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Email</label>
        <input name="email" type="email">
      </div>
      <div class="form-group">
        <label>Phone</label>
        <input name="phone">
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Blood Type</label>
        <select name="blood_type" required>
          <option value="">Select</option>
          <?php foreach(['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $t): ?>
            <option value="<?= $t ?>"><?= $t ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Last Donation Date</label>
        <input name="last_donation_date" type="date">
      </div>
    </div>
    <div class="form-group">
      <label>Address</label>
      <input name="address">
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>City</label>
        <select name="city" required>
          <option value="">Select city</option>
          <?php foreach(['Tirunelveli','Coimbatore','Madurai','Tiruchirappalli','Salem','Chennai','Nagercoil','Tiruppu','Thoothukudi','Pudukkottai','Namakkal','Erode'] as $t): ?>
            <option value="<?= $t ?>"><?= $t ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group"><label>State</label><input name="state"></div>
      <div class="form-group"><label>ZIP</label><input name="zip"></div>
    </div>
    <div class="form-group">
      <label>Health Notes</label>
      <textarea name="health_notes" rows="3"></textarea>
    </div>
    <button class="btn btn-primary" type="submit"><i class="fas fa-user-plus"></i> Save Donor</button>
  </form>
</section>
<?php include __DIR__ . '/../../partials/footer.php'; ?>

<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$id = (int)($_POST['id'] ?? 0);

$stmt = $pdo->prepare("UPDATE donors SET first_name=?, last_name=?, email=?, phone=?, blood_type=?, last_donation_date=?, address=?, city=?, state=?, zip=?, health_notes=? WHERE id=?");
$stmt->execute([
  $_POST['first_name'] ?? '',
  $_POST['last_name'] ?? '',
  $_POST['email'] ?? null,
  $_POST['phone'] ?? null,
  $_POST['blood_type'] ?? '',
  $_POST['last_donation_date'] ?? null,
  $_POST['address'] ?? null,
  $_POST['city'] ?? null,
  $_POST['state'] ?? null,
  $_POST['zip'] ?? null,
  $_POST['health_notes'] ?? null,
  $id
]);
flash_set('ok','Donor updated.');
redirect(base_url('donors/view.php?id='.$id));

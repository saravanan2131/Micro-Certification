<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();

$q = trim($_GET['q'] ?? '');
if ($q) {
  $stmt = $pdo->prepare("SELECT * FROM donors WHERE first_name LIKE ? OR last_name LIKE ? OR blood_type = ? ORDER BY id DESC");
  $like = "%$q%";
  $stmt->execute([$like, $like, $q]);
  $rows = $stmt->fetchAll();
} else {
  $rows = $pdo->query("SELECT * FROM donors ORDER BY id DESC")->fetchAll();
}
include __DIR__ . '/../../partials/header.php';
?>
<section class="card">
  <div style="display:flex; justify-content:space-between; align-items:center;">
    <h2 style="color:var(--primary);">Donors</h2>
    <div>
      <form method="get" style="display:flex; gap:.5rem;">
        <input type="text" name="q" placeholder="Search by name or blood type" value="<?= h($q) ?>">
        <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i> Search</button>
        <a class="btn" href="<?= base_url('donors/new.php') ?>"><i class="fas fa-user-plus"></i> New Donor</a>
      </form>
    </div>
  </div>
  <table class="table">
    <thead><tr><th>ID</th><th>Name</th><th>Blood</th><th>Phone</th><th>Last Donation</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach($rows as $d): ?>
        <tr>
          <td><?= (int)$d['id'] ?></td>
          <td><?= h($d['first_name'] . ' ' . $d['last_name']) ?></td>
          <td><?= h($d['blood_type']) ?></td>
          <td><?= h($d['phone']) ?></td>
          <td><?= h($d['last_donation_date']) ?></td>
          <td>
            <a class="btn" href="<?= base_url('donors/view.php?id='.(int)$d['id']) ?>">View</a>
            <a class="btn" href="<?= base_url('donors/edit.php?id='.(int)$d['id']) ?>">Edit</a>
            <a class="btn" onclick="return confirm('Delete this donor?')" href="<?= base_url('donors/remove.php?id='.(int)$d['id']) ?>">Delete</a>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</section>
<?php include __DIR__ . '/../../partials/footer.php'; ?>

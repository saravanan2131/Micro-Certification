<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$code = $_GET['code'] ?? '';
$stmt = $pdo->prepare("SELECT r.*, h.name AS hospital FROM requests r LEFT JOIN hospitals h ON h.id=r.hospital_id WHERE request_code=?");
$stmt->execute([$code]);
$r = $stmt->fetch();
include __DIR__ . '/../../partials/header.php';
if (!$r): ?>
  <div class="card">Request not found.</div>
<?php else: ?>
<section class="card">
  <h2 style="color:var(--primary);">Request <?= h($r['request_code']) ?></h2>
  <p><b>Patient:</b> <?= h($r['patient_name']) ?> |
     <b>Blood:</b> <?= h($r['blood_type']) ?> |
     <b>Units:</b> <?= (int)$r['units'] ?> |
     <b>Hospital:</b> <?= h($r['hospital'] ?? '—') ?></p>
  <p><b>Status:</b> <span class="status <?= h($r['status']) ?>"><?= h(ucfirst($r['status'])) ?></span></p>
  <div style="display:flex; gap:.5rem;">
    <a class="btn" href="<?= base_url('requests/process.php?code='.urlencode($r['request_code']).'&action=complete') ?>">Mark Completed</a>
    <a class="btn" href="<?= base_url('requests/process.php?code='.urlencode($r['request_code']).'&action=reject') ?>">Reject</a>
  </div>
</section>
<?php endif; ?>
<?php include __DIR__ . '/../../partials/footer.php'; ?>

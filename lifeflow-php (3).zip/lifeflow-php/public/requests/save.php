<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();

$patient_name = $_POST['patient_name'] ?? '';
$blood_type = $_POST['blood_type'] ?? '';
$units = max(1, (int)($_POST['units'] ?? 1));
$hospital_id = $_POST['hospital_id'] ?: null;
$hospital_address = $_POST['hospital_address'] ?? '';

if (!$patient_name || !$blood_type) {
  flash_set('err','Fill required fields.');
  redirect(base_url('requests/new.php'));
}

$code = 'REQ-' . (string)random_int(10000, 99999);

// ✅ Insert hospital_address properly
$stmt = $pdo->prepare("INSERT INTO requests 
    (request_code, patient_name, blood_type, units, hospital_id, hospital_address, status) 
    VALUES (?, ?, ?, ?, ?, ?, 'pending')");

$stmt->execute([$code, $patient_name, $blood_type, $units, $hospital_id, $hospital_address]);

flash_set('ok', "Request $code created.");
redirect(base_url('requests/list.php'));

<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$rows = $pdo->query("
  SELECT r.*, h.name as hospital
  FROM requests r
  LEFT JOIN hospitals h ON h.id=r.hospital_id
  ORDER BY r.id DESC
")->fetchAll();
include __DIR__ . '/../../partials/header.php';
?>
<section class="card">
  <div style="display:flex; justify-content:space-between; align-items:center;">
    <h2 style="color:var(--primary);">Blood Requests</h2>
    <a class="btn btn-primary" href="<?= base_url('requests/new.php') ?>"><i class="fas fa-plus"></i> Create Request</a>
  </div>
  <table class="table">
    <thead><tr><th>Code</th><th>Patient</th><th>Blood</th><th>Units</th><th>Hospital</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
      <tr>
        <td><?= h($r['request_code']) ?></td>
        <td><?= h($r['patient_name']) ?></td>
        <td><?= h($r['blood_type']) ?></td>
        <td><?= (int)$r['units'] ?></td>
        <td><?= h($r['hospital'] ?? '—') ?></td>
        <td><span class="status <?= h($r['status']) ?>"><?= h(ucfirst($r['status'])) ?></span></td>
        <td>
          <a class="btn" href="<?= base_url('requests/view.php?code='.urlencode($r['request_code'])) ?>">View</a>
          <a class="btn" href="<?= base_url('requests/process.php?code='.urlencode($r['request_code']).'&action=complete') ?>">Complete</a>
          <a class="btn" href="<?= base_url('requests/process.php?code='.urlencode($r['request_code']).'&action=reject') ?>">Reject</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</section>
<?php include __DIR__ . '/../../partials/footer.php'; ?>

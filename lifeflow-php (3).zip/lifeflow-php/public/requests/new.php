<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$hospitals = $pdo->query("SELECT id, name FROM hospitals ORDER BY name")->fetchAll();
include __DIR__ . '/../../partials/header.php';
?>
<section class="card">
  <h2 style="color:var(--primary);">Create Blood Request</h2>
  <form method="post" action="<?= base_url('requests/save.php') ?>">
    <div class="form-row">
      <div class="form-group"><label>Patient Name</label><input required name="patient_name"></div>
      <div class="form-group">
        <label>Blood Type</label>
        <select name="blood_type" required>
          <option value="">Select</option>
          <?php foreach(['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $t): ?>
            <option value="<?= $t ?>"><?= $t ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group"><label>Units</label><input type="number" min="1" name="units" required></div>
    </div>
    <div class="form-group">
      <label>Hospital Name</label>
      <select name="hospital_id">
        <option value="">Select hospital</option>
        <?php foreach($hospitals as $h): ?>
          <option value="<?= (int)$h['id'] ?>"><?= h($h['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
  <label>Hospital Address</label>
  <input type="text" name="hospital_address" placeholder="Enter hospital address" required>
</div>
    <button class="btn btn-primary"><i class="fas fa-save"></i> Save Request</button>
  </form>
</section>
<?php include __DIR__ . '/../../partials/footer.php'; ?>

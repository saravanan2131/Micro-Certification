<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$code = $_GET['code'] ?? '';
$action = $_GET['action'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM requests WHERE request_code=?");
$stmt->execute([$code]);
$r = $stmt->fetch();

if (!$r) { flash_set('err','Request not found.'); redirect(base_url('requests/list.php')); }

if ($action === 'complete') {
  // Deduct units from stock if available
  $bt = $r['blood_type'];
  $need = (int)$r['units'];

  // Sum available units
  $available = (int)$pdo->prepare("SELECT COALESCE(SUM(units),0) FROM blood_stock WHERE blood_type=?")->execute([$bt]) ?: 0;
  $stmt2 = $pdo->prepare("SELECT COALESCE(SUM(units),0) AS u FROM blood_stock WHERE blood_type=?");
  $stmt2->execute([$bt]);
  $available = (int)$stmt2->fetchColumn();

  if ($available < $need) {
    flash_set('err', "Not enough $bt stock. Needed $need, have $available.");
    redirect(base_url('requests/view.php?code='.$code));
  }

  // Consume using FEFO (earliest expiry first)
  $rows = $pdo->prepare("SELECT * FROM blood_stock WHERE blood_type=? ORDER BY expiry_date ASC");
  $rows->execute([$bt]);
  $rows = $rows->fetchAll();
  $remaining = $need;
  foreach ($rows as $row) {
    if ($remaining <= 0) break;
    $consume = min($remaining, (int)$row['units']);
    $pdo->prepare("UPDATE blood_stock SET units = units - ? WHERE id=?")->execute([$consume, $row['id']]);
    // Remove empty rows
    $pdo->prepare("DELETE FROM blood_stock WHERE id=? AND units<=0")->execute([$row['id']]);
    $remaining -= $consume;
  }

  $pdo->prepare("UPDATE requests SET status='completed' WHERE id=?")->execute([$r['id']]);
  flash_set('ok', "Request $code completed and inventory updated.");
} elseif ($action === 'reject') {
  $pdo->prepare("UPDATE requests SET status='rejected' WHERE id=?")->execute([$r['id']]);
  flash_set('ok', "Request $code rejected.");
}

redirect(base_url('requests/list.php'));

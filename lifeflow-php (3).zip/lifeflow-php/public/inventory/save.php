<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$bt = $_POST['blood_type'] ?? '';
$units = max(1, (int)($_POST['units'] ?? 1));
$expiry = $_POST['expiry_date'] ?? null;

if (!$bt || !$expiry) {
  flash_set('err','Fill required fields.');
  redirect(base_url('inventory/add.php'));
}

$stmt = $pdo->prepare("INSERT INTO blood_stock(blood_type,units,expiry_date) VALUES(?,?,?)");
$stmt->execute([$bt,$units,$expiry]);
flash_set('ok','Stock added.');
redirect(base_url('inventory/list.php'));

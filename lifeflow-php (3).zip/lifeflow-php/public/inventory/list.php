<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$rows = $pdo->query("SELECT * FROM blood_stock ORDER BY expiry_date ASC")->fetchAll();
include __DIR__ . '/../../partials/header.php';
?>
<section class="card">
  <div style="display:flex; justify-content:space-between; align-items:center;">
    <h2 style="color:var(--primary);">Inventory</h2>
    <a class="btn btn-primary" href="<?= base_url('inventory/add.php') ?>"><i class="fas fa-plus"></i> Add Stock</a>
  </div>
  <table class="table">
    <thead><tr><th>ID</th><th>Blood</th><th>Units</th><th>Expiry</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td><?= h($r['blood_type']) ?></td>
          <td><?= (int)$r['units'] ?></td>
          <td><?= h($r['expiry_date']) ?></td>
          <td>
            <a class="btn" href="<?= base_url('inventory/remove.php?id='.(int)$r['id']) ?>" onclick="return confirm('Delete this stock record?')">Delete</a>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</section>
<?php include __DIR__ . '/../../partials/footer.php'; ?>

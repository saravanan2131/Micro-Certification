<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();
$id = (int)($_GET['id'] ?? 0);
$pdo->prepare("DELETE FROM blood_stock WHERE id=?")->execute([$id]);
flash_set('ok','Stock record deleted.');
redirect(base_url('inventory/list.php'));

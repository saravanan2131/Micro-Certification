<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
include __DIR__ . '/../../partials/header.php';
?>
<section class="card">
  <h2 style="color:var(--primary);">Stock</h2>
  <form method="post" action="<?= base_url('inventory/save.php') ?>">
    <div class="form-row">
      <div class="form-group">
        <label>Blood Type</label>
        <select name="blood_type" required>
          <option value="">Select</option>
          <?php foreach(['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $t): ?>
            <option value="<?= $t ?>"><?= $t ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Units</label>
        <input type="number" name="units" min="1" required>
      </div>
      <div class="form-group">
        <label>Expiry Date</label>
        <input type="date" name="expiry_date" required>
      </div>
    </div>
    <button class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
  </form>
</section>
<?php include __DIR__ . '/../../partials/footer.php'; ?>

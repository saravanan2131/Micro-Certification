<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/util.php';
$pdo = db();

$by_type = $pdo->query("SELECT blood_type, COALESCE(SUM(units),0) total FROM blood_stock GROUP BY blood_type")->fetchAll();
$donors_by_type = $pdo->query("SELECT blood_type, COUNT(*) cnt FROM donors GROUP BY blood_type")->fetchAll(PDO::FETCH_KEY_PAIR);
$requests_status = $pdo->query("SELECT status, COUNT(*) cnt FROM requests GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);

include __DIR__ . '/../../partials/header.php';
?>
<section class="card">
  <h2 style="color:var(--primary);">Reports</h2>
  <div class="grid grid-4">
    <div class="card">
      <h3>Inventory by Blood Type</h3>
      <ul>
        <?php foreach($by_type as $r): ?>
          <li><?= h($r['blood_type']) ?> — <b><?= (int)$r['total'] ?></b> units</li>
        <?php endforeach; ?>
      </ul>
    </div>
    <div class="card">
      <h3>Donors by Blood Type</h3>
      <ul>
        <?php foreach($donors_by_type as $t=>$c): ?>
          <li><?= h($t) ?> — <b><?= (int)$c ?></b> donors</li>
        <?php endforeach; ?>
      </ul>
    </div>
    <div class="card">
      <h3>Requests by Status</h3>
      <ul>
        <?php foreach($requests_status as $s=>$c): ?>
          <li><?= h(ucfirst($s)) ?> — <b><?= (int)$c ?></b></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</section>
<?php include __DIR__ . '/../../partials/footer.php'; ?>

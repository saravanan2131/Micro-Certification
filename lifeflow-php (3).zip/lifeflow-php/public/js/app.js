document.addEventListener('DOMContentLoaded', () => {
  const flash = document.querySelector('[data-flash]');
  if (flash && flash.textContent.trim().length) {
    setTimeout(()=> { flash.style.display='none'; }, 4000);
  }
});

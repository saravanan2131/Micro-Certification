<?php
require_once __DIR__ . '/../config/db.php';
$pdo = db();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("UPDATE users SET password_hash=? WHERE username=?");
    if ($stmt->execute([$new_password, $username])) {
        $message = "Password reset successful!";
    } else {
        $message = "Error resetting password.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Forgot Password</title></head>
<body>
<h2>Reset Password</h2>
<p style="color:green;"><?= $message ?></p>
<form method="post">
  <input type="text" name="username" placeholder="Username" required><br>
  <input type="password" name="new_password" placeholder="New Password" required><br>
  <button type="submit">Reset Password</button>
</form>
</body>
</html>
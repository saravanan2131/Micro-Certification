<?php
if (session_status() === PHP_SESSION_NONE) session_start();

// ✅ include only once and in the right order
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/db.php';   // this contains db()
require_once __DIR__ . '/../../lib/util.php';

$pdo = db(); // now db() will work

// totals
$total_units = (int)$pdo->query("SELECT COALESCE(SUM(units),0) FROM blood_stock")->fetchColumn();
$registered_donors = (int)$pdo->query("SELECT COUNT(*) FROM donors")->fetchColumn();
$pending_requests = (int)$pdo->query("SELECT COUNT(*) FROM requests WHERE status='pending'")->fetchColumn();
$expiring_14 = (int)$pdo->query("SELECT COUNT(*) FROM blood_stock WHERE expiry_date <= DATE_ADD(CURDATE(), INTERVAL 14 DAY)")->fetchColumn();

// inventory by type
$by_type = $pdo->query("
    SELECT blood_type, COALESCE(SUM(units),0) as total 
    FROM blood_stock 
    GROUP BY blood_type 
    ORDER BY FIELD(blood_type,'A+','A-','B+','B-','AB+','AB-','O+','O-')
")->fetchAll();

// recent requests
$recent = $pdo->query("
    SELECT r.request_code, r.patient_name, r.blood_type, r.units, r.status, h.name AS hospital
    FROM requests r 
    LEFT JOIN hospitals h ON h.id = r.hospital_id
    ORDER BY r.id DESC 
    LIMIT 5
")->fetchAll();
?>

<?php include dirname(__DIR__, 2) . '/partials/header.php'; ?>

<section class="grid grid-4">
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div>
        <div style="color:#777;">Total Blood Units</div>
        <div style="font-size:2rem; color:var(--primary); font-weight:700;"><?= $total_units ?></div>
      </div>
      <div class="status" style="background:rgba(198,40,40,.15); color:var(--primary);"><i class="fas fa-tint"></i></div>
    </div>
    <p style="margin-top:.6rem; color:#666;">Units expiring in 14 days: <b><?= $expiring_14 ?></b></p>
  </div>
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div>
        <div style="color:#777;">Registered Donors</div>
        <div style="font-size:2rem; color:var(--primary); font-weight:700;"><?= $registered_donors ?></div>
      </div>
      <div class="status" style="background:rgba(33,150,243,.15); color:var(--info);"><i class="fas fa-user-friends"></i></div>
    </div>
    <p style="margin-top:.6rem; color:#666;">Manage donors from the Donors module.</p>
  </div>
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div>
        <div style="color:#777;">Pending Requests</div>
        <div style="font-size:2rem; color:var(--primary); font-weight:700;"><?= $pending_requests ?></div>
      </div>
      <div class="status" style="background:rgba(255,152,0,.15); color:var(--warning);"><i class="fas fa-file-medical"></i></div>
    </div>
    <p style="margin-top:.6rem; color:#666;">Process requests to fulfil demand.</p>
  </div>
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div>
        <div style="color:#777;">Expiring Soon</div>
        <div style="font-size:2rem; color:var(--primary); font-weight:700;"><?= $expiring_14 ?></div>
      </div>
      <div class="status" style="background:rgba(76,175,80,.15); color:var(--success);"><i class="fas fa-clock"></i></div>
    </div>
    <p style="margin-top:.6rem; color:#666;">Within next 14 days</p>
  </div>
</section>

<section class="card">
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
    <h2 style="color:var(--primary); margin:0;">Blood Inventory</h2>
    <a href="<?= base_url('inventory/add.php') ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Add Stock</a>
  </div>
  <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));">
    <?php foreach ($by_type as $row): ?>
    <div class="card" style="border:2px solid var(--light); text-align:center;">
      <div style="font-size:1.4rem; font-weight:700; color:var(--primary);"><?= h($row['blood_type']) ?></div>
      <div style="font-size:1.8rem; font-weight:700;"><?= (int)$row['total'] ?></div>
      <div class="status" style="display:inline-block; background:#eee; color:#555;">in stock</div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<section class="card">
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
    <h2 style="color:var(--primary); margin:0;">Recent Blood Requests</h2>
    <a href="<?= base_url('requests/list.php') ?>" class="btn btn-primary">View All</a>
  </div>
  <table class="table">
    <thead>
      <tr><th>Request ID</th><th>Patient</th><th>Blood</th><th>Units</th><th>Hospital</th><th>Status</th><th>Actions</th></tr>
    </thead>
    <tbody>
    <?php foreach ($recent as $r): ?>
      <tr>
        <td><?= h($r['request_code']) ?></td>
        <td><?= h($r['patient_name']) ?></td>
        <td><?= h($r['blood_type']) ?></td>
        <td><?= (int)$r['units'] ?></td>
        <td><?= h($r['hospital'] ?? '—') ?></td>
        <td><span class="status <?= h($r['status']) ?>"><?= h(ucfirst($r['status'])) ?></span></td>
        <td><a class="btn" href="<?= base_url('requests/view.php?code=' . urlencode($r['request_code'])) ?>">View</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>

<?php include dirname(__DIR__, 2) . '/partials/footer.php'; ?>

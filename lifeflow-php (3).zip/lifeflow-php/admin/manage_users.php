<?php
require_once 'auth.php';
require_once __DIR__ . '/../config/db.php';
$pdo = db();

// Handle Add / Edit / Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $username = trim($_POST['username']);
        $password_hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $role = $_POST['role'];
        $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?,?,?)");
        $stmt->execute([$username, $password_hash, $role]);
    }
    if (isset($_POST['update'])) {
        $id = $_POST['id'];
        $role = $_POST['role'];
        $stmt = $pdo->prepare("UPDATE users SET role=? WHERE id=?");
        $stmt->execute([$role, $id]);
    }
    if (isset($_POST['delete'])) {
        $id = $_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM users WHERE id=?");
        $stmt->execute([$id]);
    }
}

$users = $pdo->query("SELECT * FROM users")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>User Management</title></head>
<body>
<h2>User Management</h2>
<table border="1">
<tr><th>ID</th><th>Username</th><th>Role</th><th>Actions</th></tr>
<?php foreach($users as $u): ?>
<tr>
  <td><?= $u['id'] ?></td>
  <td><?= $u['username'] ?></td>
  <td><?= $u['role'] ?></td>
  <td>
    <form method="post" style="display:inline;">
      <input type="hidden" name="id" value="<?= $u['id'] ?>">
      <select name="role">
        <option value="admin" <?= $u['role']=='admin'?'selected':'' ?>>Admin</option>
        <option value="staff" <?= $u['role']=='staff'?'selected':'' ?>>Staff</option>
      </select>
      <button type="submit" name="update">Update</button>
    </form>
    <form method="post" style="display:inline;">
      <input type="hidden" name="id" value="<?= $u['id'] ?>">
      <button type="submit" name="delete">Delete</button>
    </form>
  </td>
</tr>
<?php endforeach; ?>
</table>

<h3>Add New User</h3>
<form method="post">
  <input type="text" name="username" placeholder="Username" required>
  <input type="password" name="password" placeholder="Password" required>
  <select name="role">
    <option value="admin">Admin</option>
    <option value="staff">Staff</option>
  </select>
  <button type="submit" name="add">Add</button>
</form>
</body>
</html>
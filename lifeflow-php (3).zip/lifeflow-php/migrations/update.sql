-- Patch to add hospital_address column to requests table
ALTER TABLE requests 
ADD COLUMN hospital_address VARCHAR(255) NOT NULL AFTER hospital_id;

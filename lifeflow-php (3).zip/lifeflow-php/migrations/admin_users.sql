-- SQL script to create admin_users table and insert default admin user

CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('superadmin', 'admin', 'staff') DEFAULT 'admin',
    failed_attempts INT DEFAULT 0,
    last_login DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default superadmin user
-- Username: admin
-- Password: admin123

INSERT INTO admin_users (username, password, role)
VALUES ('admin', '$2y$10$3ZgUYPvEn0O3YwUuMx1eqO9x1zIbjJ.nI2vqCffmTbdVwQ5F2lP5m', 'superadmin');

-- Create database (run separately if needed)
-- CREATE DATABASE blood_bank CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE blood_bank;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','staff') DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS donors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(150),
  phone VARCHAR(30),
  blood_type ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NOT NULL,
  last_donation_date DATE NULL,
  address VARCHAR(255),
  city VARCHAR(120),
  state VARCHAR(120),
  zip VARCHAR(20),
  health_notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS hospitals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  address VARCHAR(255),
  city VARCHAR(120),
  state VARCHAR(120),
  zip VARCHAR(20),
  phone VARCHAR(30),
  email VARCHAR(150)
);

CREATE TABLE IF NOT EXISTS blood_stock (
  id INT AUTO_INCREMENT PRIMARY KEY,
  blood_type ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NOT NULL,
  units INT NOT NULL DEFAULT 0,
  expiry_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS donations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  donor_id INT NOT NULL,
  blood_type ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NOT NULL,
  units INT NOT NULL DEFAULT 1,
  donation_date DATE NOT NULL,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  request_code VARCHAR(20) UNIQUE,
  patient_name VARCHAR(150) NOT NULL,
  blood_type ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NOT NULL,
  units INT NOT NULL,
  hospital_id INT,
  hospital_address VARCHAR(255) NOT NULL,
  status ENUM('pending','completed','rejected') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE SET NULL
);


-- Seed minimal data
INSERT IGNORE INTO users (id, username, password_hash, role)
VALUES (1, 'admin', SHA2('admin123',256), 'admin');

-- Existing hospitals
INSERT IGNORE INTO hospitals (id, name, city, state, phone)
VALUES
(1, 'City Hospital', 'Mumbai', 'MH', '022-1111-2222'),
(2, 'Central Hospital', 'Delhi', 'DL', '011-3333-4444'),
(3, 'Metro Medical', 'Bengaluru', 'KA', '080-5555-6666');

-- Tamil Nadu hospitals
INSERT IGNORE INTO hospitals (name, address, city, state, phone, email) VALUES
('Kaveri Hospital', 'Trichy Main Road', 'Tiruchirappalli', 'Tamil Nadu', '0431-4006000', 'info@kaverihospital.com'),
('Apollo Hospitals', 'Greams Road', 'Chennai', 'Tamil Nadu', '044-2829-3333', 'apollochennai@apollohospitals.com'),
('MIOT International', 'Manapakkam', 'Chennai', 'Tamil Nadu', '044-4200-2288', 'info@miotinternational.com'),
('Fortis Malar Hospital', 'Adyar', 'Chennai', 'Tamil Nadu', '044-4289-2222', 'contact@fortismalar.com'),
('PSG Hospitals', 'Peelamedu', 'Coimbatore', 'Tamil Nadu', '0422-2570170', 'info@psghospitals.com'),
('Christian Medical College (CMC)', 'Vellore', 'Vellore', 'Tamil Nadu', '0416-2281000', 'info@cmcvellore.ac.in'),
('SRM Medical College Hospital', 'Potheri', 'Kattankulathur', 'Tamil Nadu', '044-4743-2500', 'info@srmhospital.com'),
('Rajiv Gandhi Government General Hospital', 'Park Town', 'Chennai', 'Tamil Nadu', '044-2530-5000', 'info@rgggh.org'),
('Government Stanley Medical College Hospital', 'Washermanpet', 'Chennai', 'Tamil Nadu', '044-2528-1616', 'info@stanleyhospital.org'),
('Madurai Meenakshi Mission Hospital', 'Lake Area', 'Madurai', 'Tamil Nadu', '0452-426-3000', 'info@mmh.org');

-- Seed some stock
INSERT INTO blood_stock (blood_type, units, expiry_date) VALUES
('A+', 42, DATE_ADD(CURDATE(), INTERVAL 25 DAY)),
('A-', 18, DATE_ADD(CURDATE(), INTERVAL 15 DAY)),
('B+', 35, DATE_ADD(CURDATE(), INTERVAL 30 DAY)),
('B-', 12, DATE_ADD(CURDATE(), INTERVAL 12 DAY)),
('AB+', 28, DATE_ADD(CURDATE(), INTERVAL 28 DAY)),
('AB-', 8,  DATE_ADD(CURDATE(), INTERVAL 9 DAY)),
('O+', 65, DATE_ADD(CURDATE(), INTERVAL 35 DAY)),
('O-', 15, DATE_ADD(CURDATE(), INTERVAL 20 DAY));
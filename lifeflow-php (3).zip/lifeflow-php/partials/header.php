<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<?php require_once __DIR__ . '/../config/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo APP_NAME; ?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="<?php echo base_url('style.css'); ?>">
  <script defer src="<?php echo base_url('js/app.js'); ?>"></script>
</head>
<body>
<header>
  <div style="display:flex; align-items:center; gap:.6rem;">
    <i class="fas fa-tint" style="font-size:1.6rem;"></i>
    <h1 style="font-size:1.2rem; margin:0;">LifeFlow Blood Management</h1>
  </div>
  <nav>
    <!-- 🔗 Changed Admin link to login.php -->
    <a href="<?php echo base_url('admin/login.php'); ?>" class="btn btn-outline">Admin</a>
    <a href="<?php echo base_url('donors/list.php'); ?>" class="btn btn-outline">Donors</a>
    <a href="<?php echo base_url('requests/list.php'); ?>" class="btn btn-outline">Requests</a>
    <a href="<?php echo base_url('inventory/list.php'); ?>" class="btn btn-outline">Inventory</a>
    <a href="<?php echo base_url('reports/index.php'); ?>" class="btn btn-outline">Reports</a>
  </nav>
</header>
<div class="container">
  <aside class="sidebar">
  <h3 style="margin:.2rem 0 1rem;color:#c62828;">Quick Actions</h3>
  <div style="display:flex; flex-direction:column; gap:.2rem;">
    <a class="active" href="<?php echo base_url('index.php'); ?>"><i class="fas fa-home"></i> Dashboard</a>
    <a href="<?php echo base_url('donors/new.php'); ?>"><i class="fas fa-user-plus"></i> Add Donor</a>
    <a href="<?php echo base_url('requests/new.php'); ?>"><i class="fas fa-file-medical"></i> Create Request</a>
    <a href="<?php echo base_url('inventory/add.php'); ?>"><i class="fas fa-vial"></i> Add Blood Stock</a>
    <!-- 🔗 Changed Admin Users link to manage_users.php -->
    <a href="<?php echo base_url('admin/manage_users.php'); ?>"><i class="fas fa-users-cog"></i> Manage Admins</a>
  </div>
  <?php if ($msg = flash_get('ok')): ?>
    <div class="card" data-flash style="margin-top:1rem; background:#e8f5e9;">✅ <?php echo h($msg); ?></div>
  <?php endif; ?>
  <?php if ($msg = flash_get('err')): ?>
    <div class="card" data-flash style="margin-top:1rem; background:#ffebee;">⚠️ <?php echo h($msg); ?></div>
  <?php endif; ?>
</aside>

<main class="main">

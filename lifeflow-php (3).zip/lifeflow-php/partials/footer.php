</main>
</div>
<footer>
  <p>© <?php echo date('Y'); ?> LifeFlow Blood Management System</p>
</footer>
</body>
</html>

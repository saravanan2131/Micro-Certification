<?php
require_once __DIR__ . '/../config/db.php';
session_start();
$pdo = db();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? '');
    $p = trim($_POST['password'] ?? '');

    if ($u && $p) {
        $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ?");
        $stmt->execute([$u]);
        $user = $stmt->fetch();

        if ($user && password_verify($p, $user['password'])) {
            $_SESSION['admin'] = [
                'id' => $user['id'],
                'username' => $user['username']
            ];
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "❌ Invalid username or password.";
        }
    } else {
        $error = "⚠️ All fields are required.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin Login - LifeFlow</title>
  <link rel="stylesheet" href="../assets/style.css">
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    .error { color: red; margin-bottom: 10px; }
    form { max-width: 300px; }
    label { display: block; margin-top: 10px; }
    input { width: 100%; padding: 8px; }
    button { margin-top: 15px; padding: 10px; width: 100%; }
  </style>
</head>
<body>
  <h2>🔐 Admin Login</h2>
  <?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
  <form method="post">
    <label>Username</label>
    <input type="text" name="username" required>
    <label>Password</label>
    <input type="password" name="password" required>
    <button type="submit">Login</button>
  </form>
</body>
</html>

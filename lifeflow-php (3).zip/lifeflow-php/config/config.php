<?php
// Update these for your local MySQL
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'blood_bank');
define('DB_USER', 'root');
define('DB_PASS', '');

// App settings
define('APP_NAME', 'LifeFlow - Blood Management System');
define('BASE_URL', '/lifeflow-php/public'); // adjust if not using this path

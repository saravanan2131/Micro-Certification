<?php
require_once __DIR__ . '/../config/db.php';
$pdo = db();

// Create users table if not exists
$pdo->exec("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','staff') NOT NULL DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;");

// Seed default admin
$cnt = $pdo->query("SELECT COUNT(*) as c FROM users")->fetch()['c'] ?? 0;
if ($cnt == 0) {
    $username = 'admin';
    $password_hash = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'admin')");
    $stmt->execute([$username, $password_hash]);
}
?>
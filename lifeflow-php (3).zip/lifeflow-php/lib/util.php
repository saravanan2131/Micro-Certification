<?php
function h($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }

function redirect($path) {
    header('Location: ' . $path);
    exit;
}

function flash_set($key, $msg) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['flash'][$key] = $msg;
}

function flash_get($key) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!empty($_SESSION['flash'][$key])) {
        $m = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $m;
    }
    return null;
}

function base_url($path = '') {
    return rtrim(constant('BASE_URL'), '/') . ($path ? '/' . ltrim($path, '/') : '');
}
